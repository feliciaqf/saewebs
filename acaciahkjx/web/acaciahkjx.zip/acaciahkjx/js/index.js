(function(){
	$(document).on("click ", "#nav_mobile", function (e) {
		var $container = $("#container");
		if ($container.css('left') == '0px') {
			acaciaMain.navMenuMobile.open();
		} else {
			acaciaMain.navMenuMobile.close();
		}
	})
})
