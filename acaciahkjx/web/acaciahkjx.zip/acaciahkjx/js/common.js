var acaciaMain = {
	init: function() {

	},
	navMenuMobile: {

		open: function() {
			$("#container, #footer").addClass("mobile-menu-open");
			$('#tab_main_nav_close_mobile').addClass("show-table-cell").show().siblings('#tab_main_nav_mobile,#tab_main_need_help_mobile').addClass("hidden").hide();
			$("#tab_main_nav_mobile_container").addClass("mobile-menu-open");
		},

		close: function() {
			$("#tab_main_nav_mobile_container").removeClass("mobile-menu-open").css({
				'right': -100 + '%'
			});
			$("#container, #footer").removeClass("mobile-menu-open").css('left', 0);
			$('#tab_main_nav_close_mobile').removeClass("show-table-cell").hide().siblings().removeClass("hidden").show();
			$("#tab_main_nav_mobile_next_container").removeClass("mobile-menu-open")
				.animate({
					'right': -100 + '%'
				}, function() {});
		}
	}
};
